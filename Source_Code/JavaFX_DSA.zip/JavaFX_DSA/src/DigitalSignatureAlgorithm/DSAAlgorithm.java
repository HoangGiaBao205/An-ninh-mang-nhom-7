package DigitalSignatureAlgorithm;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class DSAAlgorithm {
    private BigInteger p, q, g, x, y, k;
    private SecureRandom random = new SecureRandom();

    // TẠO KHÓA DSA
    // THIẾT LẬP KHÓA THỦ CÔNG
    public void setManualKeys(BigInteger p, BigInteger q, BigInteger g, BigInteger x) {
        this.p = p;
        this.q = q;
        this.g = g;
        this.x = x;
        this.y = g.modPow(x, p);
        generateK();
    }
    
    public void generateKeys() {
        int qLength = 160; 
        int pLength = 512; 
        q = new BigInteger(qLength, 50, random);
        BigInteger temp;
        BigInteger pMinusOne;
        do {
            temp = new BigInteger(pLength - qLength, random);
            pMinusOne = temp.multiply(q);
            p = pMinusOne.add(BigInteger.ONE);
        } while (!p.isProbablePrime(50));
        //g = h^((p-1)/q) mod p (với 1 < h < p-1)
        BigInteger h;
        do {
            h = new BigInteger(pLength - 1, random);
        } while (h.compareTo(BigInteger.ONE) <= 0 || h.compareTo(pMinusOne) >= 0);
        g = h.modPow(pMinusOne.divide(q), p);
        // x (0 < x < q)
        do {
            x = new BigInteger(qLength, random);
        } while (x.compareTo(BigInteger.ZERO) <= 0 || x.compareTo(q) >= 0);
        // y = g^x mod p
        y = g.modPow(x, p);
        // Tạo k (0 < k < q)
        generateK();
    }

    private void generateK() {
        if (q != null) {
            do {
                k = new BigInteger(q.bitLength(), random);
            } while (k.compareTo(BigInteger.ZERO) <= 0 || k.compareTo(q) >= 0);
        }
    }

    // KÝ VĂN BẢN
    public BigInteger[] signMessage(String message, String algorithm) throws Exception {
        if (p == null || q == null || g == null || x == null) {
            throw new Exception("Vui lòng tạo khóa trước khi ký!");
        }

        BigInteger hashMessage = getHash(message, algorithm);
        BigInteger r, s;

        do {
            generateK(); 
            // r = (g^k mod p) mod q
            r = g.modPow(k, p).mod(q);
            // s = (k^-1 * (H(m) + x*r)) mod q
            BigInteger kInv = k.modInverse(q);
            s = kInv.multiply(hashMessage.add(x.multiply(r))).mod(q);

        } while (r.equals(BigInteger.ZERO) || s.equals(BigInteger.ZERO));

        return new BigInteger[]{r, s};
    }

    // XÁC MINH CHỮ KÝ
    public boolean verifySignature(String message, BigInteger r, BigInteger s, String algorithm) 
    		throws Exception {
        if (p == null || q == null || g == null || y == null) {
            throw new Exception("Thiếu khóa công khai để xác minh!");
        }
        if (r.compareTo(BigInteger.ZERO) <= 0 || r.compareTo(q) >= 0 ||
            s.compareTo(BigInteger.ZERO) <= 0 || s.compareTo(q) >= 0) {
            return false;
        }

        BigInteger hashMessage = getHash(message, algorithm);

        // w = s^-1 mod q
        BigInteger w = s.modInverse(q);
        // u1 = (H(m) * w) mod q
        BigInteger u1 = hashMessage.multiply(w).mod(q);
        // u2 = (r * w) mod q
        BigInteger u2 = r.multiply(w).mod(q);
        // v = ((g^u1 * y^u2) mod p) mod q
        BigInteger v = (g.modPow(u1, p).multiply(y.modPow(u2, p))).mod(p).mod(q);

        return v.equals(r);
    }

    private BigInteger getHash(String message, String algorithm) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance(algorithm);
        byte[] hashBytes = md.digest(message.getBytes());
        return new BigInteger(1, hashBytes);
    }

    // Getters
    public BigInteger getP() { return p; }
    public BigInteger getQ() { return q; }
    public BigInteger getG() { return g; }
    public BigInteger getY() { return y; }
    public BigInteger getX() { return x; }
    public BigInteger getK() { return k; }
}