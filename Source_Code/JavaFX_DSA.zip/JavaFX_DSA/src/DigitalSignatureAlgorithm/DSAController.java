package DigitalSignatureAlgorithm;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;

// Import thư viện Apache POI để đọc file Word (.docx) và Excel (.xlsx, .xls)
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;

// Import thư viện Apache PDFBox để đọc file PDF
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.Loader;

public class DSAController {

    @FXML private TextField txtP;
    @FXML private TextField txtQ;
    @FXML private TextField txtG;
    @FXML private TextField txtX;
    @FXML private TextField txtY;
    @FXML private TextField txtK;
    @FXML private Button btnGenKeyRandom;
    @FXML private Button btnReset;
    @FXML private Button btnExit;
    @FXML private Button btnSaveKey;
    @FXML private Button btnLoadKey;
    @FXML private Button btnGenKeyManual;

    @FXML private Button btnSignOpenFile;
    @FXML private TextArea txtSignMessage;
    @FXML private ComboBox<String> cbHashAlgo;
    @FXML private TextArea txtSignSignature;
    @FXML private Button btnSign;
    @FXML private Button btnTransferData;
    @FXML private Button btnSaveSignature;

    @FXML private Button btnVerifyOpenFile;
    @FXML private TextArea txtVerifyMessage;
    @FXML private Button btnVerifyOpenSigFile;
    @FXML private TextArea txtVerifySignature;
    @FXML private Button btnVerify;
    // ==========================================

    private DSAAlgorithm dsa = new DSAAlgorithm();

    // ========================================================
    // TÍNH NĂNG BẮT LỖI NGAY KHI VỪA NHẬP XONG (REAL-TIME VALIDATION)
    // ========================================================
    @FXML
    public void initialize() {
        txtP.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused && !txtP.getText().isEmpty()) checkP();
        });

        txtQ.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused && !txtQ.getText().isEmpty()) checkQ();
        });

        txtG.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused && !txtG.getText().isEmpty()) checkG();
        });

        txtX.focusedProperty().addListener((obs, wasFocused, isNowFocused) -> {
            if (!isNowFocused && !txtX.getText().isEmpty()) checkX();
        });
    }

    private void checkP() {
        try {
            BigInteger p = new BigInteger(txtP.getText().trim(), 16);
            if (!p.isProbablePrime(50)) {
                txtP.setStyle("-fx-border-color: red; -fx-border-width: 2;");
                showAlert(Alert.AlertType.WARNING, "Lỗi toán học", "Số p không phải là số nguyên tố!");
            } else {
                txtP.setStyle("-fx-border-color: green; -fx-border-width: 2;");
            }
        } catch (Exception e) {
            txtP.setStyle("-fx-border-color: red; -fx-border-width: 2;");
        }
    }

    private void checkQ() {
        try {
            BigInteger q = new BigInteger(txtQ.getText().trim(), 16);
            if (!q.isProbablePrime(50)) {
                txtQ.setStyle("-fx-border-color: red; -fx-border-width: 2;");
                showAlert(Alert.AlertType.WARNING, "Lỗi toán học", "Số q không phải là số nguyên tố!");
                return;
            }
            if (!txtP.getText().isEmpty()) {
                BigInteger p = new BigInteger(txtP.getText().trim(), 16);
                if (!p.subtract(BigInteger.ONE).remainder(q).equals(BigInteger.ZERO)) {
                    txtQ.setStyle("-fx-border-color: red; -fx-border-width: 2;");
                    showAlert(Alert.AlertType.WARNING, "Lỗi toán học", "q phải là ước của (p - 1)!");
                    return;
                }
            }
            txtQ.setStyle("-fx-border-color: green; -fx-border-width: 2;");
        } catch (Exception e) {
            txtQ.setStyle("-fx-border-color: red; -fx-border-width: 2;");
        }
    }

    private void checkG() {
        try {
            BigInteger g = new BigInteger(txtG.getText().trim(), 16);
            if (!txtP.getText().isEmpty() && !txtQ.getText().isEmpty()) {
                BigInteger p = new BigInteger(txtP.getText().trim(), 16);
                BigInteger q = new BigInteger(txtQ.getText().trim(), 16);
                
                if (g.compareTo(BigInteger.ONE) <= 0 || g.compareTo(p) >= 0 || !g.modPow(q, p).equals(BigInteger.ONE)) {
                    txtG.setStyle("-fx-border-color: red; -fx-border-width: 2;");
                    showAlert(Alert.AlertType.WARNING, "Lỗi toán học", "Phần tử sinh g không hợp lệ!\nĐiều kiện bắt buộc: g^q mod p = 1");
                    return;
                }
            }
            txtG.setStyle("-fx-border-color: green; -fx-border-width: 2;");
        } catch (Exception e) {
            txtG.setStyle("-fx-border-color: red; -fx-border-width: 2;");
        }
    }

    private void checkX() {
        try {
            BigInteger x = new BigInteger(txtX.getText().trim(), 16);
            if (!txtQ.getText().isEmpty()) {
                BigInteger q = new BigInteger(txtQ.getText().trim(), 16);
                if (x.compareTo(BigInteger.ZERO) <= 0 || x.compareTo(q) >= 0) {
                    txtX.setStyle("-fx-border-color: red; -fx-border-width: 2;");
                    showAlert(Alert.AlertType.WARNING, "Lỗi giới hạn", "Khóa bí mật x phải thỏa mãn: 0 < x < q");
                    return;
                }
            }
            txtX.setStyle("-fx-border-color: green; -fx-border-width: 2;");
        } catch (Exception e) {
            txtX.setStyle("-fx-border-color: red; -fx-border-width: 2;");
        }
    }

    // ------------------------------------------------------------------
    // HÀM ĐỌC FILE THÔNG MINH (TXT, DOCX, PDF, XLSX)
    // ------------------------------------------------------------------
    private String readFileContent(File file) {
        String fileName = file.getName().toLowerCase();
        try {
            // 1. XỬ LÝ FILE WORD (.docx)
            if (fileName.endsWith(".docx")) {
                StringBuilder content = new StringBuilder();
                try (FileInputStream fis = new FileInputStream(file);
                     XWPFDocument document = new XWPFDocument(fis)) {
                    for (XWPFParagraph paragraph : document.getParagraphs()) {
                        content.append(paragraph.getText()).append("\n");
                    }
                }
                return content.toString(); 
            } 
            // 2. XỬ LÝ FILE EXCEL (.xlsx hoặc .xls)
            else if (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
                StringBuilder content = new StringBuilder();
                try (FileInputStream fis = new FileInputStream(file);
                     Workbook workbook = WorkbookFactory.create(fis)) {
                    for (Sheet sheet : workbook) {
                        for (Row row : sheet) {
                            for (Cell cell : row) {
                                content.append(cell.toString()).append("\t");
                            }
                            content.append("\n");
                        }
                    }
                }
                return content.toString();
            }
            // 3. XỬ LÝ FILE PDF (.pdf) - Đã cập nhật cho PDFBox 3.x
            else if (fileName.endsWith(".pdf")) {
                // SỬ DỤNG Loader.loadPDF THAY VÌ PDDocument.load
                try (PDDocument document = Loader.loadPDF(file)) {
                    if (document.isEncrypted()) {
                        showAlert(Alert.AlertType.ERROR, "Lỗi bảo mật", "File PDF này đã bị đặt mật khẩu bảo vệ, không thể đọc dữ liệu!");
                        return "";
                    }
                    PDFTextStripper stripper = new PDFTextStripper();
                    return stripper.getText(document);
                }
            }
            // 4. XỬ LÝ FILE TEXT THƯỜNG (.txt, .sig...)
            else {
                return new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())), java.nio.charset.StandardCharsets.UTF_8);
            }
            
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi đọc file", "Không thể đọc nội dung file: " + e.getMessage());
            return "";
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    @FXML
    void handleGenKeyManual(ActionEvent event) {
        String pStr = txtP.getText().trim();
        String qStr = txtQ.getText().trim();
        String gStr = txtG.getText().trim();
        String xStr = txtX.getText().trim();

        if (pStr.isEmpty() || qStr.isEmpty() || gStr.isEmpty() || xStr.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng nhập đầy đủ các tham số p, q, g và khóa bí mật x!");
            return;
        }

        try {
            BigInteger p = new BigInteger(pStr, 16);
            BigInteger q = new BigInteger(qStr, 16);
            BigInteger g = new BigInteger(gStr, 16);
            BigInteger x = new BigInteger(xStr, 16);

            if (!p.isProbablePrime(50)) { showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số p không phải là số nguyên tố!"); return; }
            if (!q.isProbablePrime(50)) { showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số q không phải là số nguyên tố!"); return; }

            BigInteger pMinus1 = p.subtract(BigInteger.ONE);
            if (!pMinus1.remainder(q).equals(BigInteger.ZERO)) {
                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số q phải là ước của (p - 1).");
                return;
            }

            if (g.compareTo(BigInteger.ONE) <= 0 || g.compareTo(p) >= 0) {
                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Phần tử sinh g phải lớn hơn 1 và nhỏ hơn p.");
                return;
            }

            if (!g.modPow(q, p).equals(BigInteger.ONE)) {
                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số g bạn nhập không phải là phần tử sinh hợp lệ!");
                return;
            }

            if (x.compareTo(BigInteger.ZERO) <= 0 || x.compareTo(q) >= 0) {
                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Khóa bí mật x phải thỏa mãn: 0 < x < q.");
                return;
            }

            dsa.setManualKeys(p, q, g, x);
            txtY.setText(dsa.getY().toString(16));
            txtK.setText(dsa.getK().toString(16));

            showAlert(Alert.AlertType.INFORMATION, "Thành công", "Tạo khóa thủ công hợp lệ!");

        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi định dạng", "Vui lòng chỉ nhập chuỗi Hex hợp lệ (không chứa ký tự lạ).");
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", e.getMessage());
        }
    }
    
    @FXML
    void handleGenKeyRandom(ActionEvent event) {
        dsa.generateKeys();
        txtP.setStyle(""); txtQ.setStyle(""); txtG.setStyle(""); txtX.setStyle("");
        
        txtP.setText(dsa.getP().toString(16));
        txtQ.setText(dsa.getQ().toString(16));
        txtG.setText(dsa.getG().toString(16));
        txtX.setText(dsa.getX().toString(16));
        txtY.setText(dsa.getY().toString(16));
        txtK.setText(dsa.getK().toString(16));
        
        showAlert(Alert.AlertType.INFORMATION, "Thành công", "Tạo khóa DSA ngẫu nhiên thành công!");
    }

    @FXML
    void handleReset(ActionEvent event) {
        txtP.clear(); txtQ.clear(); txtG.clear();
        txtX.clear(); txtY.clear(); txtK.clear();
        txtP.setStyle(""); txtQ.setStyle(""); txtG.setStyle(""); txtX.setStyle("");
        
        txtSignMessage.clear(); txtSignSignature.clear();
        txtVerifyMessage.clear(); txtVerifySignature.clear(); 
        dsa = new DSAAlgorithm(); 
    }

    @FXML void handleExit(ActionEvent event) { System.exit(0); }
    
    @FXML
    void handleSaveKey(ActionEvent event) {
        if (txtP.getText().isEmpty() || txtQ.getText().isEmpty() || txtX.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Trên giao diện chưa có khóa để lưu!");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Lưu file bộ khóa DSA");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Key Files (*.txt)", "*.txt"));

        Stage stage = (Stage) btnSaveKey.getScene().getWindow();
        File file = fileChooser.showSaveDialog(stage);

        if (file != null) {
            try (FileOutputStream fos = new FileOutputStream(file)) {
                Properties props = new Properties();
                props.setProperty("p", txtP.getText().trim());
                props.setProperty("q", txtQ.getText().trim());
                props.setProperty("g", txtG.getText().trim());
                props.setProperty("x", txtX.getText().trim());
                props.setProperty("y", txtY.getText().trim());

                props.store(fos, "FILE LUU BO KHOA DSA");
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã lưu bộ khóa thành công!");
            } catch (IOException e) {
                showAlert(Alert.AlertType.ERROR, "Lỗi lưu file", "Không thể lưu file: " + e.getMessage());
            }
        }
    }
    
    @FXML
    void handleLoadKey(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Chọn file bộ khóa DSA");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Key Files *.txt", "*.txt"));

        Stage stage = (Stage) btnLoadKey.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            try (FileInputStream fis = new FileInputStream(file)) {
                Properties props = new Properties();
                props.load(fis); 

                String pStr = props.getProperty("p");
                String qStr = props.getProperty("q");
                String gStr = props.getProperty("g");
                String xStr = props.getProperty("x");

                if (pStr == null || qStr == null || gStr == null || xStr == null) {
                    showAlert(Alert.AlertType.ERROR, "Lỗi định dạng", "File khóa bị hỏng hoặc thiếu các tham số cơ bản.");
                    return;
                }

                BigInteger p = new BigInteger(pStr, 16);
                BigInteger q = new BigInteger(qStr, 16);
                BigInteger g = new BigInteger(gStr, 16);
                BigInteger x = new BigInteger(xStr, 16);

                dsa.setManualKeys(p, q, g, x);
                txtP.setStyle(""); txtQ.setStyle(""); txtG.setStyle(""); txtX.setStyle("");

                txtP.setText(dsa.getP().toString(16));
                txtQ.setText(dsa.getQ().toString(16));
                txtG.setText(dsa.getG().toString(16));
                txtX.setText(dsa.getX().toString(16));
                txtY.setText(dsa.getY().toString(16));
                txtK.setText(dsa.getK().toString(16));

                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã tải bộ khóa thành công!");
            } catch (Exception e) {
                showAlert(Alert.AlertType.ERROR, "Lỗi đọc file", "Đã xảy ra lỗi: " + e.getMessage());
            }
        }
    }

    @FXML
    void handleSignOpenFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Chọn file văn bản cần ký");
        // Mở rộng bộ lọc cho phép chọn cả .pdf và .xlsx/.xls
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Tài liệu hỗ trợ (*.txt, *.docx, *.pdf, *.xlsx, *.xls)", "*.txt", "*.docx", "*.pdf", "*.xlsx", "*.xls"));

        Stage stage = (Stage) btnSignOpenFile.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            txtSignMessage.setText(readFileContent(file));
        }
    }
    
    @FXML
    void handleSign(ActionEvent event) {
        String message = txtSignMessage.getText();
        String hashAlgo = cbHashAlgo.getValue();
        
        if (message == null || message.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng nhập/mở nội dung văn bản cần ký!");
            return;
        }

        try {
            BigInteger[] signature = dsa.signMessage(message, hashAlgo);
            txtSignSignature.setText(signature[0].toString(16) + ",\n" + signature[1].toString(16));
            txtK.setText(dsa.getK().toString(16));
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi khi ký", e.getMessage());
        }
    }

    @FXML
    void handleTransferData(ActionEvent event) {
        txtVerifyMessage.setText(txtSignMessage.getText());
        txtVerifySignature.setText(txtSignSignature.getText());
    }

    @FXML
    void handleSaveSignature(ActionEvent event) {
        if (txtSignSignature.getText().isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Chưa có chữ ký để lưu!");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Lưu file chữ ký");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Chữ ký (.sig, .txt)", "*.sig", "*.txt"));
        
        Stage stage = (Stage) btnSaveSignature.getScene().getWindow();
        File file = fileChooser.showSaveDialog(stage);

        if (file != null) {
            try (FileWriter writer = new FileWriter(file)) {
                writer.write(txtSignSignature.getText());
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã lưu chữ ký thành công!");
            } catch (IOException e) {
                showAlert(Alert.AlertType.ERROR, "Lỗi lưu file", e.getMessage());
            }
        }
    }

    @FXML
    void handleVerifyOpenFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Chọn file văn bản cần kiểm tra");
        // Mở rộng bộ lọc cho phép chọn cả .pdf và .xlsx/.xls khi xác thực
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Tài liệu hỗ trợ (*.txt, *.docx, *.pdf, *.xlsx, *.xls)", "*.txt", "*.docx", "*.pdf", "*.xlsx", "*.xls"));
        
        Stage stage = (Stage) btnVerifyOpenFile.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            txtVerifyMessage.setText(readFileContent(file));
        }
    }

    @FXML
    void handleVerifyOpenSigFile(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Chọn file chứa chữ ký");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Chữ ký (.sig, .txt)", "*.sig", "*.txt"));
        
        Stage stage = (Stage) btnVerifyOpenSigFile.getScene().getWindow();
        File file = fileChooser.showOpenDialog(stage);

        if (file != null) {
            txtVerifySignature.setText(readFileContent(file));
        }
    }

    @FXML
    void handleVerify(ActionEvent event) {
        String message = txtVerifyMessage.getText();
        String sigText = txtVerifySignature.getText();
        String hashAlgo = cbHashAlgo.getValue(); 
        if (message == null || message.isEmpty() || sigText == null || sigText.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng cung cấp đầy đủ văn bản và chữ ký!");
            return;
        }
        try {
            String[] parts = sigText.split(",");
            if (parts.length != 2) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký đã bị thay đổi!");
                return;
            }
            BigInteger r;
            BigInteger s;
            try {
                r = new BigInteger(parts[0].trim(), 16);
                s = new BigInteger(parts[1].trim(), 16);
            } catch (NumberFormatException ex) {
                showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký đã bị thay đổi!");
                return;
            }
            if (dsa.getQ() != null) {
                if (r.compareTo(BigInteger.ZERO) <= 0 || r.compareTo(dsa.getQ()) >= 0 ||
                    s.compareTo(BigInteger.ZERO) <= 0 || s.compareTo(dsa.getQ()) >= 0) {
                    showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký đã bị thay đổi!");
                    return;
                }
            }
            boolean isValid = dsa.verifySignature(message, r, s, hashAlgo);
            if (isValid) {
                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Văn bản hợp lệ");
            } else {
                String originalMsg = txtSignMessage.getText();
                String originalSig = txtSignSignature.getText();
                if (originalMsg != null && !originalMsg.isEmpty() && originalSig != null && !originalSig.isEmpty()) {
                    boolean isMessageChanged = !message.equals(originalMsg);
                    boolean isSignatureChanged = !sigText.equals(originalSig);
                    if (isMessageChanged && isSignatureChanged) {
                        showAlert(Alert.AlertType.ERROR, "Cảnh báo", "Văn bản và chữ ký đã bị thay đổi");
                    } else if (isMessageChanged) {
                        showAlert(Alert.AlertType.ERROR, "Cảnh báo", "Văn bản đã bị thay đổi");
                    } else if (isSignatureChanged) 
                        showAlert(Alert.AlertType.ERROR, "Cảnh báo", "Chữ ký đã bị thay đổi");
                } 
                else 
                    showAlert(Alert.AlertType.ERROR, "Cảnh báo", "Văn bản hoặc chữ ký đã bị thay đổi");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", "Đã xảy ra lỗi: " + e.getMessage());
        }
    }
}


//package DigitalSignatureAlgorithm;
//
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.scene.control.Alert;
//import javafx.scene.control.Button;
//import javafx.scene.control.ComboBox;
//import javafx.scene.control.TextArea;
//import javafx.scene.control.TextField;
//import javafx.stage.FileChooser;
//import javafx.stage.Stage;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.FileOutputStream;
//import java.util.Properties;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.math.BigInteger;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.apache.poi.xwpf.usermodel.XWPFParagraph;
//
//public class DSAController {
//
//    @FXML private TextField txtP;
//    @FXML private TextField txtQ;
//    @FXML private TextField txtG;
//    @FXML private TextField txtX;
//    @FXML private TextField txtY;
//    @FXML private TextField txtK;
//    @FXML private Button btnGenKeyRandom;
//    @FXML private Button btnReset;
//    @FXML private Button btnExit;
//    @FXML private Button btnSaveKey;
//    @FXML private Button btnLoadKey;
//    @FXML private Button btnGenKeyManual;
//
//    @FXML private Button btnSignOpenFile;
//    @FXML private TextArea txtSignMessage;
//    @FXML private ComboBox<String> cbHashAlgo;
//    @FXML private TextArea txtSignSignature;
//    @FXML private Button btnSign;
//    @FXML private Button btnTransferData;
//    @FXML private Button btnSaveSignature;
//
//    @FXML private Button btnVerifyOpenFile;
//    @FXML private TextArea txtVerifyMessage;
//    @FXML private Button btnVerifyOpenSigFile;
//    @FXML private TextArea txtVerifySignature;
//    @FXML private Button btnVerify;
//    // ==========================================
//
//    
//    private DSAAlgorithm dsa = new DSAAlgorithm();
//
//
//    private String readFileContent(File file) {
//        String fileName = file.getName().toLowerCase();
//        try {
//            if (fileName.endsWith(".docx")) {
//                StringBuilder content = new StringBuilder();
//                try (FileInputStream fis = new FileInputStream(file);
//                     XWPFDocument document = new XWPFDocument(fis)) {
//                    
//                    for (XWPFParagraph paragraph : document.getParagraphs()) {
//                        content.append(paragraph.getText()).append("\n");
//                    }
//                }
//                return content.toString().trim(); 
//            } 
//            else {
//                return new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
//            }
//            
//        } catch (Exception e) {
//            showAlert(Alert.AlertType.ERROR, "Lỗi đọc file", "Không thể đọc nội dung file: " + e.getMessage());
//            return "";
//        }
//    }
//
//    private void showAlert(Alert.AlertType type, String title, String content) {
//        Alert alert = new Alert(type);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(content);
//        alert.showAndWait();
//    }
//
//    @FXML
//    void handleGenKeyManual(ActionEvent event) {
//        String pStr = txtP.getText().trim();
//        String qStr = txtQ.getText().trim();
//        String gStr = txtG.getText().trim();
//        String xStr = txtX.getText().trim();
//
//        if (pStr.isEmpty() || qStr.isEmpty() || gStr.isEmpty() || xStr.isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng nhập đầy đủ các tham số p, q, g và khóa bí mật x!");
//            return;
//        }
//
//        try {
//            BigInteger p = new BigInteger(pStr);
//            BigInteger q = new BigInteger(qStr);
//            BigInteger g = new BigInteger(gStr);
//            BigInteger x = new BigInteger(xStr);
//
//            if (!p.isProbablePrime(50)) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số p = " + p + " không phải là số nguyên tố!");
//                return;
//            }
//            if (!q.isProbablePrime(50)) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số q = " + q + " không phải là số nguyên tố!");
//                return;
//            }
//
//            BigInteger pMinus1 = p.subtract(BigInteger.ONE);
//            if (!pMinus1.remainder(q).equals(BigInteger.ZERO)) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số q phải là ước của (p - 1).\nBạn đã nhập sai định lý cơ bản của DSA!");
//                return;
//            }
//
//            if (g.compareTo(BigInteger.ONE) <= 0 || g.compareTo(p) >= 0) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Phần tử sinh g phải lớn hơn 1 và nhỏ hơn p.");
//                return;
//            }
//
//            if (!g.modPow(q, p).equals(BigInteger.ONE)) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Số g bạn nhập không phải là phần tử sinh hợp lệ!\nĐiều kiện bắt buộc: (g^q mod p) = 1.");
//                return;
//            }
//
//            if (x.compareTo(BigInteger.ZERO) <= 0 || x.compareTo(q) >= 0) {
//                showAlert(Alert.AlertType.ERROR, "Sai điều kiện", "Khóa bí mật x phải thỏa mãn: 0 < x < q.");
//                return;
//            }
//
//            dsa.setManualKeys(p, q, g, x);
//
//            // Cập nhật lên UI
//            txtY.setText(dsa.getY().toString());
//            txtK.setText(dsa.getK().toString());
//
//            showAlert(Alert.AlertType.INFORMATION, "Thành công", "Tạo khóa thủ công hợp lệ!\nHệ thống đã tự động tính toán khóa công khai y = " + dsa.getY().toString());
//
//        } catch (NumberFormatException e) {
//            showAlert(Alert.AlertType.ERROR, "Lỗi định dạng", "Vui lòng chỉ nhập số nguyên (không chứa chữ cái hay khoảng trắng).");
//        } catch (Exception e) {
//            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", e.getMessage());
//        }
//    }
//    
//    @FXML
//    void handleGenKeyRandom(ActionEvent event) {
//        dsa.generateKeys();
//        
//        txtP.setText(dsa.getP().toString());
//        txtQ.setText(dsa.getQ().toString());
//        txtG.setText(dsa.getG().toString());
//        txtX.setText(dsa.getX().toString());
//        txtY.setText(dsa.getY().toString());
//        txtK.setText(dsa.getK().toString());
//        
//        showAlert(Alert.AlertType.INFORMATION, "Thành công", "Tạo khóa DSA ngẫu nhiên thành công!");
//    }
//
//    @FXML
//    void handleReset(ActionEvent event) {
//        txtP.clear(); txtQ.clear(); txtG.clear();
//        txtX.clear(); txtY.clear(); txtK.clear();
//        
//        txtSignMessage.clear(); txtSignSignature.clear();
//        txtVerifyMessage.clear(); txtVerifySignature.clear(); 
//        
//        dsa = new DSAAlgorithm(); 
//    }
//
//    @FXML void handleExit(ActionEvent event) { System.exit(0); }
//    
//    @FXML
//    void handleSaveKey(ActionEvent event) {
//
//        if (txtP.getText().isEmpty() || txtQ.getText().isEmpty() || txtX.getText().isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Trên giao diện chưa có khóa để lưu!");
//            return;
//        }
//
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Lưu file bộ khóa DSA");
//
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Key Files (*.txt)", "*.txt"));
//
//        Stage stage = (Stage) btnSaveKey.getScene().getWindow();
//        File file = fileChooser.showSaveDialog(stage);
//
//        if (file != null) {
//            try (FileOutputStream fos = new FileOutputStream(file)) {
//
//                Properties props = new Properties();
//                props.setProperty("p", txtP.getText().trim());
//                props.setProperty("q", txtQ.getText().trim());
//                props.setProperty("g", txtG.getText().trim());
//                props.setProperty("x", txtX.getText().trim());
//                props.setProperty("y", txtY.getText().trim());
//
//
//                props.store(fos, "FILE LUU BO KHOA DSA");
//                
//                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã lưu bộ khóa thành công tại:\n" + file.getAbsolutePath());
//            } catch (IOException e) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi lưu file", "Không thể lưu file: " + e.getMessage());
//            }
//        }
//    }
//    
//    @FXML
//    void handleLoadKey(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Chọn file bộ khóa DSA");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Key Files *.txt", "*.txt"));
//
//        Stage stage = (Stage) btnLoadKey.getScene().getWindow();
//        File file = fileChooser.showOpenDialog(stage);
//
//        if (file != null) {
//            try (FileInputStream fis = new FileInputStream(file)) {
//                Properties props = new Properties();
//                props.load(fis); 
//
//                String pStr = props.getProperty("p");
//                String qStr = props.getProperty("q");
//                String gStr = props.getProperty("g");
//                String xStr = props.getProperty("x");
//
//
//                if (pStr == null || qStr == null || gStr == null || xStr == null) {
//                    showAlert(Alert.AlertType.ERROR, "Lỗi định dạng", "File khóa bị hỏng hoặc thiếu các tham số cơ bản (p, q, g, x).");
//                    return;
//                }
//
//                BigInteger p = new BigInteger(pStr);
//                BigInteger q = new BigInteger(qStr);
//                BigInteger g = new BigInteger(gStr);
//                BigInteger x = new BigInteger(xStr);
//
//
//                dsa.setManualKeys(p, q, g, x);
//
//                txtP.setText(dsa.getP().toString());
//                txtQ.setText(dsa.getQ().toString());
//                txtG.setText(dsa.getG().toString());
//                txtX.setText(dsa.getX().toString());
//                txtY.setText(dsa.getY().toString());
//                txtK.setText(dsa.getK().toString());
//
//                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã tải bộ khóa thành công!");
//
//            } catch (NumberFormatException e) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi dữ liệu", "Dữ liệu trong file không phải là số nguyên hợp lệ.");
//            } catch (Exception e) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi đọc file", "Đã xảy ra lỗi: " + e.getMessage());
//            }
//        }
//    }
//
//    @FXML
//    void handleSignOpenFile(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Chọn file văn bản cần ký");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Tài liệu (.txt, .docx)", "*.txt", "*.docx"));
//
//        Stage stage = (Stage) btnSignOpenFile.getScene().getWindow();
//        File file = fileChooser.showOpenDialog(stage);
//
//        if (file != null) {
//            txtSignMessage.setText(readFileContent(file));
//        }
//    }
//
//    
//    @FXML
//    void handleSign(ActionEvent event) {
//        String message = txtSignMessage.getText();
//        String hashAlgo = cbHashAlgo.getValue();
//        
//        if (message == null || message.isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng nhập/mở nội dung văn bản cần ký!");
//            return;
//        }
//
//        try {
//            BigInteger[] signature = dsa.signMessage(message, hashAlgo);
//            
//            String rHex = signature[0].toString(16);
//            String sHex = signature[1].toString(16);
//
//            txtSignSignature.setText(rHex + ",\n" + sHex);
//            txtK.setText(dsa.getK().toString(16));
//            
//        } catch (Exception e) {
//            showAlert(Alert.AlertType.ERROR, "Lỗi khi ký", e.getMessage());
//        }
//    }
//
//    @FXML
//    void handleTransferData(ActionEvent event) {
//        txtVerifyMessage.setText(txtSignMessage.getText());
//        txtVerifySignature.setText(txtSignSignature.getText());
//    }
//
//    @FXML
//    void handleSaveSignature(ActionEvent event) {
//        if (txtSignSignature.getText().isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Chưa có chữ ký để lưu!");
//            return;
//        }
//
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Lưu file chữ ký");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Chữ ký (.sig, .txt)", "*.sig", "*.txt"));
//        
//        Stage stage = (Stage) btnSaveSignature.getScene().getWindow();
//        File file = fileChooser.showSaveDialog(stage);
//
//        if (file != null) {
//            try (FileWriter writer = new FileWriter(file)) {
//                writer.write(txtSignSignature.getText());
//                showAlert(Alert.AlertType.INFORMATION, "Thành công", "Đã lưu chữ ký thành công!");
//            } catch (IOException e) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi lưu file", "Không thể lưu file: " + e.getMessage());
//            }
//        }
//    }
//
//    @FXML
//    void handleVerifyOpenFile(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Chọn file văn bản cần kiểm tra");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Tài liệu (.txt, .docx)", "*.txt", "*.docx"));
//        
//        Stage stage = (Stage) btnVerifyOpenFile.getScene().getWindow();
//        File file = fileChooser.showOpenDialog(stage);
//
//        if (file != null) {
//            txtVerifyMessage.setText(readFileContent(file));
//        }
//    }
//
//    @FXML
//    void handleVerifyOpenSigFile(ActionEvent event) {
//        FileChooser fileChooser = new FileChooser();
//        fileChooser.setTitle("Chọn file chứa chữ ký");
//        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Chữ ký (.sig, .txt)", "*.sig", "*.txt"));
//        
//        Stage stage = (Stage) btnVerifyOpenSigFile.getScene().getWindow();
//        File file = fileChooser.showOpenDialog(stage);
//
//        if (file != null) {
//            txtVerifySignature.setText(readFileContent(file));
//        }
//    }
//
//
//    @FXML
//    void handleVerify(ActionEvent event) {
//        String message = txtVerifyMessage.getText();
//        String sigText = txtVerifySignature.getText();
//        String hashAlgo = cbHashAlgo.getValue(); 
//
//        if (message == null || message.isEmpty() || sigText == null || sigText.isEmpty()) {
//            showAlert(Alert.AlertType.WARNING, "Cảnh báo", "Vui lòng cung cấp đầy đủ văn bản và chữ ký!");
//            return;
//        }
//
//        try {
//            String[] parts = sigText.split(",");
//            if (parts.length != 2) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký không hợp lệ!");
//                return;
//            }
//
//            BigInteger r;
//            BigInteger s;
//            try {
//                // Dịch ngược từ Hex (Hệ 16) về Hệ 10
//                r = new BigInteger(parts[0].trim(), 16);
//                s = new BigInteger(parts[1].trim(), 16);
//            } catch (NumberFormatException ex) {
//                showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký không hợp lệ!");
//                return;
//            }
//
//            if (dsa.getQ() != null) {
//                if (r.compareTo(BigInteger.ZERO) <= 0 || r.compareTo(dsa.getQ()) >= 0 ||
//                    s.compareTo(BigInteger.ZERO) <= 0 || s.compareTo(dsa.getQ()) >= 0) {
//                    showAlert(Alert.AlertType.ERROR, "Lỗi", "Chữ ký không hợp lệ!");
//                    return;
//                }
//            }
//
//            boolean isValid = dsa.verifySignature(message, r, s, hashAlgo);
//
//
//            if (isValid) {
//                showAlert(Alert.AlertType.INFORMATION, "Xác thực thành công", "Văn bản xác thực hợp lệ!");
//            } else {
//
//                String originalMsg = txtSignMessage.getText();
//                String originalSig = txtSignSignature.getText();
//
//                if (originalMsg != null && !originalMsg.isEmpty() && originalSig != null && !originalSig.isEmpty()) {
//                    boolean isMessageChanged = !message.equals(originalMsg);
//                    boolean isSignatureChanged = !sigText.equals(originalSig);
//
//                    if (isMessageChanged && isSignatureChanged) {
//                        showAlert(Alert.AlertType.ERROR, "Xác thực không thành công", "Văn bản và chữ ký không hợp lệ!");
//                    } else if (isMessageChanged) {
//                        showAlert(Alert.AlertType.ERROR, "Xác thực không thành công", "Văn bản không hợp lệ!");
//                    } else if (isSignatureChanged) {
//                        showAlert(Alert.AlertType.ERROR, "Xác thực không thành công", "Chữ ký không hợp lệ!");
//                    }
//                } 
//                else {
//                    showAlert(Alert.AlertType.ERROR, "Xác thực không thành công", "Văn bản hoặc chữ ký không hợp lệ!");
//                }
//            }
//
//        } catch (Exception e) {
//            showAlert(Alert.AlertType.ERROR, "Lỗi hệ thống", "Đã xảy ra lỗi: " + e.getMessage());
//        }
//    }
//}