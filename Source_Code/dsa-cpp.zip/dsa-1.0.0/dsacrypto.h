#ifndef DSACRYPTO_H
#define DSACRYPTO_H

#include <QString>
#include <QByteArray>

class DSACrypto {
public:
    // Generate key pair (supporting 1024 or 2048 bits)
    static bool generateKeyPair(int bits, 
                                 QString &privKeyPem, 
                                 QString &pubKeyPem, 
                                 QString &p_hex, 
                                 QString &q_hex, 
                                 QString &g_hex, 
                                 QString &x_hex, 
                                 QString &y_hex,
                                 QString &errorMsg);

    // Sign data using SHA-256 and DSA private key
    static bool signData(const QByteArray &data, 
                         const QString &privKeyPem, 
                         QString &signatureBase64, 
                         QString &r_hex, 
                         QString &s_hex, 
                         QString &errorMsg);

    // Verify data using SHA-256, DSA public key, and signature
    static bool verifyData(const QByteArray &data, 
                           const QString &pubKeyPem, 
                           const QString &signatureBase64, 
                           QString &errorMsg);

    // Convert (r, s) values in hex to a standard ASN.1 DER / Base64 signature
    static bool encodeSignature(const QString &r_hex, const QString &s_hex, QString &signatureBase64, QString &errorMsg);

    // Convert standard ASN.1 DER / Base64 signature to raw (r, s) hex values
    static bool decodeSignature(const QString &signatureBase64, QString &r_hex, QString &s_hex, QString &errorMsg);

    // Helper to calculate SHA-256 hash of data
    static QByteArray calculateSHA256(const QByteArray &data);
    static QString sha256Hex(const QByteArray &data);
};

#endif // DSACRYPTO_H
