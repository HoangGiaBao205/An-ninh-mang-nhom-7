#include "dsacrypto.h"
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/core_names.h>
#include <openssl/bn.h>
#include <openssl/ecdsa.h>
#include <openssl/sha.h>

bool DSACrypto::generateKeyPair(int bits, 
                                 QString &privKeyPem, 
                                 QString &pubKeyPem, 
                                 QString &p_hex, 
                                 QString &q_hex, 
                                 QString &g_hex, 
                                 QString &x_hex, 
                                 QString &y_hex,
                                 QString &errorMsg) {
    EVP_PKEY_CTX *pctx = EVP_PKEY_CTX_new_id(EVP_PKEY_DSA, NULL);
    if (!pctx) {
        errorMsg = "Không thể khởi tạo context tạo tham số DSA.";
        return false;
    }
    
    if (EVP_PKEY_paramgen_init(pctx) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        errorMsg = "Không thể khởi tạo bộ sinh tham số.";
        return false;
    }
    
    if (EVP_PKEY_CTX_set_dsa_paramgen_bits(pctx, bits) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        errorMsg = "Lỗi thiết lập độ dài khóa.";
        return false;
    }
    
    EVP_PKEY *params = NULL;
    if (EVP_PKEY_paramgen(pctx, &params) <= 0) {
        EVP_PKEY_CTX_free(pctx);
        errorMsg = "Lỗi sinh tham số p, q, g.";
        return false;
    }
    EVP_PKEY_CTX_free(pctx);
    
    EVP_PKEY_CTX *kctx = EVP_PKEY_CTX_new(params, NULL);
    if (!kctx) {
        EVP_PKEY_free(params);
        errorMsg = "Không thể khởi tạo context tạo khóa.";
        return false;
    }
    
    if (EVP_PKEY_keygen_init(kctx) <= 0) {
        EVP_PKEY_CTX_free(kctx);
        EVP_PKEY_free(params);
        errorMsg = "Không thể khởi tạo bộ sinh cặp khóa.";
        return false;
    }
    
    EVP_PKEY *pkey = NULL;
    if (EVP_PKEY_keygen(kctx, &pkey) <= 0) {
        EVP_PKEY_CTX_free(kctx);
        EVP_PKEY_free(params);
        errorMsg = "Lỗi sinh cặp khóa.";
        return false;
    }
    EVP_PKEY_CTX_free(kctx);
    EVP_PKEY_free(params);
    
    // Extract parameters
    BIGNUM *p = NULL;
    BIGNUM *q = NULL;
    BIGNUM *g = NULL;
    BIGNUM *pub = NULL;
    BIGNUM *priv = NULL;
    
    if (EVP_PKEY_get_bn_param(pkey, OSSL_PKEY_PARAM_FFC_P, &p) &&
        EVP_PKEY_get_bn_param(pkey, OSSL_PKEY_PARAM_FFC_Q, &q) &&
        EVP_PKEY_get_bn_param(pkey, OSSL_PKEY_PARAM_FFC_G, &g) &&
        EVP_PKEY_get_bn_param(pkey, OSSL_PKEY_PARAM_PUB_KEY, &pub) &&
        EVP_PKEY_get_bn_param(pkey, OSSL_PKEY_PARAM_PRIV_KEY, &priv)) {
        
        char *p_str = BN_bn2hex(p);
        char *q_str = BN_bn2hex(q);
        char *g_str = BN_bn2hex(g);
        char *pub_str = BN_bn2hex(pub);
        char *priv_str = BN_bn2hex(priv);
        
        p_hex = QString(p_str);
        q_hex = QString(q_str);
        g_hex = QString(g_str);
        y_hex = QString(pub_str);
        x_hex = QString(priv_str);
        
        OPENSSL_free(p_str);
        OPENSSL_free(q_str);
        OPENSSL_free(g_str);
        OPENSSL_free(pub_str);
        OPENSSL_free(priv_str);
    } else {
        errorMsg = "Lỗi trích xuất tham số toán học DSA.";
        BN_free(p); BN_free(q); BN_free(g); BN_free(pub); BN_free(priv);
        EVP_PKEY_free(pkey);
        return false;
    }
    
    BN_free(p);
    BN_free(q);
    BN_free(g);
    BN_free(pub);
    BN_free(priv);
    
    // Write keys to PEM strings
    BIO *bio_priv = BIO_new(BIO_s_mem());
    if (PEM_write_bio_PrivateKey(bio_priv, pkey, NULL, NULL, 0, NULL, NULL) <= 0) {
        BIO_free(bio_priv);
        EVP_PKEY_free(pkey);
        errorMsg = "Không thể ghi Khóa bí mật dưới định dạng PEM.";
        return false;
    }
    char *priv_data = NULL;
    long priv_len = BIO_get_mem_data(bio_priv, &priv_data);
    privKeyPem = QString::fromUtf8(priv_data, priv_len);
    BIO_free(bio_priv);
    
    BIO *bio_pub = BIO_new(BIO_s_mem());
    if (PEM_write_bio_PUBKEY(bio_pub, pkey) <= 0) {
        BIO_free(bio_pub);
        EVP_PKEY_free(pkey);
        errorMsg = "Không thể ghi Khóa công khai dưới định dạng PEM.";
        return false;
    }
    char *pub_data = NULL;
    long pub_len = BIO_get_mem_data(bio_pub, &pub_data);
    pubKeyPem = QString::fromUtf8(pub_data, pub_len);
    BIO_free(bio_pub);
    
    EVP_PKEY_free(pkey);
    return true;
}

bool DSACrypto::signData(const QByteArray &data, 
                         const QString &privKeyPem, 
                         QString &signatureBase64, 
                         QString &r_hex, 
                         QString &s_hex, 
                         QString &errorMsg) {
    QByteArray pemBytes = privKeyPem.toUtf8();
    BIO *bio = BIO_new_mem_buf(pemBytes.constData(), pemBytes.size());
    EVP_PKEY *pkey = PEM_read_bio_PrivateKey(bio, NULL, NULL, NULL);
    BIO_free(bio);
    
    if (!pkey) {
        errorMsg = "Khóa bí mật không đúng định dạng PEM hoặc bị lỗi.";
        return false;
    }
    
    EVP_MD_CTX *mctx = EVP_MD_CTX_new();
    if (EVP_DigestSignInit(mctx, NULL, EVP_sha256(), NULL, pkey) <= 0) {
        EVP_PKEY_free(pkey);
        EVP_MD_CTX_free(mctx);
        errorMsg = "Khởi tạo chữ ký số thất bại.";
        return false;
    }
    
    size_t sig_len = 0;
    if (EVP_DigestSign(mctx, NULL, &sig_len, (const unsigned char*)data.constData(), data.size()) <= 0) {
        EVP_PKEY_free(pkey);
        EVP_MD_CTX_free(mctx);
        errorMsg = "Không thể xác định dung lượng chữ ký.";
        return false;
    }
    
    QByteArray sigBytes(sig_len, 0);
    if (EVP_DigestSign(mctx, (unsigned char*)sigBytes.data(), &sig_len, (const unsigned char*)data.constData(), data.size()) <= 0) {
        EVP_PKEY_free(pkey);
        EVP_MD_CTX_free(mctx);
        errorMsg = "Lỗi trong quá trình ký dữ liệu.";
        return false;
    }
    sigBytes.resize(sig_len);
    EVP_MD_CTX_free(mctx);
    EVP_PKEY_free(pkey);
    
    signatureBase64 = QString::fromLatin1(sigBytes.toBase64());
    
    // Parse r, s from ASN.1 DER signature
    const unsigned char *p = (const unsigned char*)sigBytes.constData();
    ECDSA_SIG *dsa_sig = d2i_ECDSA_SIG(NULL, &p, sigBytes.size());
    if (dsa_sig) {
        const BIGNUM *r = ECDSA_SIG_get0_r(dsa_sig);
        const BIGNUM *s = ECDSA_SIG_get0_s(dsa_sig);
        char *r_str = BN_bn2hex(r);
        char *s_str = BN_bn2hex(s);
        r_hex = QString(r_str);
        s_hex = QString(s_str);
        OPENSSL_free(r_str);
        OPENSSL_free(s_str);
        ECDSA_SIG_free(dsa_sig);
    } else {
        r_hex = "";
        s_hex = "";
    }
    
    return true;
}

bool DSACrypto::verifyData(const QByteArray &data, 
                           const QString &pubKeyPem, 
                           const QString &signatureBase64, 
                           QString &errorMsg) {
    QByteArray pemBytes = pubKeyPem.toUtf8();
    BIO *bio = BIO_new_mem_buf(pemBytes.constData(), pemBytes.size());
    EVP_PKEY *pkey = PEM_read_bio_PUBKEY(bio, NULL, NULL, NULL);
    BIO_free(bio);
    
    if (!pkey) {
        errorMsg = "Khóa công khai không đúng định dạng PEM hoặc bị lỗi.";
        return false;
    }
    
    QByteArray sigBytes = QByteArray::fromBase64(signatureBase64.toLatin1());
    if (sigBytes.isEmpty()) {
        EVP_PKEY_free(pkey);
        errorMsg = "Định dạng chữ ký số Base64 không hợp lệ.";
        return false;
    }
    
    EVP_MD_CTX *mctx = EVP_MD_CTX_new();
    if (EVP_DigestVerifyInit(mctx, NULL, EVP_sha256(), NULL, pkey) <= 0) {
        EVP_PKEY_free(pkey);
        EVP_MD_CTX_free(mctx);
        errorMsg = "Khởi tạo xác minh chữ ký thất bại.";
        return false;
    }
    
    int status = EVP_DigestVerify(mctx, (const unsigned char*)sigBytes.constData(), sigBytes.size(), 
                                   (const unsigned char*)data.constData(), data.size());
    EVP_MD_CTX_free(mctx);
    EVP_PKEY_free(pkey);
    
    if (status == 1) {
        return true;
    } else if (status == 0) {
        errorMsg = "Chữ ký số không trùng khớp hoặc dữ liệu đã bị chỉnh sửa trái phép.";
        return false;
    } else {
        errorMsg = "Lỗi hệ thống trong quá trình đối soát chữ ký.";
        return false;
    }
}

bool DSACrypto::encodeSignature(const QString &r_hex, const QString &s_hex, QString &signatureBase64, QString &errorMsg) {
    BIGNUM *r = NULL;
    BIGNUM *s = NULL;
    
    if (BN_hex2bn(&r, r_hex.trimmed().toUtf8().constData()) <= 0 ||
        BN_hex2bn(&s, s_hex.trimmed().toUtf8().constData()) <= 0) {
        BN_free(r);
        BN_free(s);
        errorMsg = "Giá trị r hoặc s không hợp lệ (yêu cầu định dạng Hexadecimal).";
        return false;
    }
    
    ECDSA_SIG *sig = ECDSA_SIG_new();
    ECDSA_SIG_set0(sig, r, s); // transfers ownership
    
    int sig_len = i2d_ECDSA_SIG(sig, NULL);
    if (sig_len <= 0) {
        ECDSA_SIG_free(sig);
        errorMsg = "Lỗi đóng gói ASN.1 DER.";
        return false;
    }
    
    QByteArray sigBytes(sig_len, 0);
    unsigned char *p = (unsigned char*)sigBytes.data();
    i2d_ECDSA_SIG(sig, &p);
    ECDSA_SIG_free(sig);
    
    signatureBase64 = QString::fromLatin1(sigBytes.toBase64());
    return true;
}

bool DSACrypto::decodeSignature(const QString &signatureBase64, QString &r_hex, QString &s_hex, QString &errorMsg) {
    QByteArray sigBytes = QByteArray::fromBase64(signatureBase64.trimmed().toLatin1());
    if (sigBytes.isEmpty()) {
        errorMsg = "Dữ liệu Base64 của chữ ký rỗng hoặc không đúng định dạng.";
        return false;
    }
    
    const unsigned char *p = (const unsigned char*)sigBytes.constData();
    ECDSA_SIG *sig = d2i_ECDSA_SIG(NULL, &p, sigBytes.size());
    if (!sig) {
        errorMsg = "Chữ ký không hợp lệ (không phải cấu trúc ASN.1 DER SEQUENCE r & s).";
        return false;
    }
    
    const BIGNUM *r = ECDSA_SIG_get0_r(sig);
    const BIGNUM *s = ECDSA_SIG_get0_s(sig);
    
    char *r_str = BN_bn2hex(r);
    char *s_str = BN_bn2hex(s);
    
    r_hex = QString(r_str);
    s_hex = QString(s_str);
    
    OPENSSL_free(r_str);
    OPENSSL_free(s_str);
    ECDSA_SIG_free(sig);
    return true;
}

QByteArray DSACrypto::calculateSHA256(const QByteArray &data) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256((const unsigned char*)data.constData(), data.size(), hash);
    return QByteArray((const char*)hash, SHA256_DIGEST_LENGTH);
}

QString DSACrypto::sha256Hex(const QByteArray &data) {
    return QString::fromLatin1(calculateSHA256(data).toHex());
}
