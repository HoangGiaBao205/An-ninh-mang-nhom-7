#include "mainwindow.h"
#include "dsacrypto.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QFormLayout>
#include <QDateTime>
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QFileInfo>
#include <QSplitter>
#include <QStyle>
#include <QScrollArea>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    setWindowTitle("🛡️ Hệ Thống Chữ Ký Số DSA - FIPS 186-4");
    setMinimumSize(950, 780);

    setupUI();
    applyStyle();
    connectSignals();

    log("Hệ thống mật mã chữ ký số DSA đã sẵn sàng.", "SYSTEM");
    log("Nhóm nghiên cứu: Nguyễn Công nghệ - Chuẩn FIPS 186-4.", "INFO");
}

MainWindow::~MainWindow() {}

void MainWindow::setupUI() {
    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    mainLayout->setContentsMargins(15, 15, 15, 15);
    mainLayout->setSpacing(12);

    tabWidget = new QTabWidget(this);

    // ================= TAB 1: CẤU HÌNH & TẠO KHÓA =================
    QWidget *tabKeys = new QWidget();
    QHBoxLayout *keysLayout = new QHBoxLayout(tabKeys);
    keysLayout->setContentsMargins(10, 10, 10, 10);
    keysLayout->setSpacing(15);

    // Cột trái: Bộ sinh khóa & Đầu ra
    QGroupBox *grpKeyLeft = new QGroupBox("1. Thiết lập Cặp Khóa");
    QVBoxLayout *keyLeftLayout = new QVBoxLayout(grpKeyLeft);
    keyLeftLayout->setSpacing(10);

    QHBoxLayout *configLayout = new QHBoxLayout();
    configLayout->addWidget(new QLabel("Độ dài khóa (L/N bits):"));
    cmbKeySize = new QComboBox();
    cmbKeySize->addItem("1024 bits (L=1024, N=160) - Nhanh", 1024);
    cmbKeySize->addItem("2048 bits (L=2048, N=256) - Tiêu chuẩn", 2048);
    cmbKeySize->setMinimumHeight(32);
    configLayout->addWidget(cmbKeySize);
    
    btnGenerateKeys = new QPushButton("🔑 Sinh Cặp Khóa Mới");
    btnGenerateKeys->setMinimumHeight(42);
    btnGenerateKeys->setCursor(Qt::PointingHandCursor);

    // Private key widget
    QVBoxLayout *privKeyArea = new QVBoxLayout();
    QHBoxLayout *privHeader = new QHBoxLayout();
    privHeader->addWidget(new QLabel("🔒 Khóa bí mật (Private Key - x) [PEM]:"));
    btnLoadPrivateKey = new QPushButton("📂 Tải");
    btnSavePrivateKey = new QPushButton("💾 Lưu");
    btnLoadPrivateKey->setFixedSize(55, 25);
    btnSavePrivateKey->setFixedSize(55, 25);
    privHeader->addWidget(btnLoadPrivateKey);
    privHeader->addWidget(btnSavePrivateKey);
    txtPrivateKey = new QTextEdit();
    txtPrivateKey->setPlaceholderText("Khóa bí mật (Private Key) được bảo vệ tại đây...");
    txtPrivateKey->setAcceptRichText(false);
    privKeyArea->addLayout(privHeader);
    privKeyArea->addWidget(txtPrivateKey);

    // Public key widget
    QVBoxLayout *pubKeyArea = new QVBoxLayout();
    QHBoxLayout *pubHeader = new QHBoxLayout();
    pubHeader->addWidget(new QLabel("🔓 Khóa công khai (Public Key - y) [PEM]:"));
    btnLoadPublicKey = new QPushButton("📂 Tải");
    btnSavePublicKey = new QPushButton("💾 Lưu");
    btnLoadPublicKey->setFixedSize(55, 25);
    btnSavePublicKey->setFixedSize(55, 25);
    pubHeader->addWidget(btnLoadPublicKey);
    pubHeader->addWidget(btnSavePublicKey);
    txtPublicKey = new QTextEdit();
    txtPublicKey->setPlaceholderText("Khóa công khai (Public Key) dùng để chia sẻ...");
    txtPublicKey->setAcceptRichText(false);
    pubKeyArea->addLayout(pubHeader);
    pubKeyArea->addWidget(txtPublicKey);

    keyLeftLayout->addLayout(configLayout);
    keyLeftLayout->addWidget(btnGenerateKeys);
    keyLeftLayout->addLayout(privKeyArea);
    keyLeftLayout->addLayout(pubKeyArea);

    // Cột phải: Các tham số toán học
    QGroupBox *grpKeyRight = new QGroupBox("2. Tham số toán học DSA (BIGNUM)");
    QVBoxLayout *keyRightLayout = new QVBoxLayout(grpKeyRight);
    keyRightLayout->setSpacing(8);

    txtParamP = new QTextEdit();
    txtParamP->setReadOnly(true);
    txtParamP->setPlaceholderText("Chưa có tham số p");
    txtParamP->setMaximumHeight(75);

    txtParamQ = new QTextEdit();
    txtParamQ->setReadOnly(true);
    txtParamQ->setPlaceholderText("Chưa có tham số q");
    txtParamQ->setMaximumHeight(50);

    txtParamG = new QTextEdit();
    txtParamG->setReadOnly(true);
    txtParamG->setPlaceholderText("Chưa có tham số g");
    txtParamG->setMaximumHeight(75);

    txtParamX = new QTextEdit();
    txtParamX->setReadOnly(true);
    txtParamX->setPlaceholderText("Chưa có tham số x");
    txtParamX->setMaximumHeight(50);

    txtParamY = new QTextEdit();
    txtParamY->setReadOnly(true);
    txtParamY->setPlaceholderText("Chưa có tham số y");
    txtParamY->setMaximumHeight(75);

    keyRightLayout->addWidget(new QLabel("Số nguyên tố lớn (p) - Modulus:"));
    keyRightLayout->addWidget(txtParamP);
    keyRightLayout->addWidget(new QLabel("Số nguyên tố phụ (q) - Divisor (p-1):"));
    keyRightLayout->addWidget(txtParamQ);
    keyRightLayout->addWidget(new QLabel("Tham số generator (g):"));
    keyRightLayout->addWidget(txtParamG);
    keyRightLayout->addWidget(new QLabel("Số ngẫu nhiên riêng tư (x) - Khóa riêng:"));
    keyRightLayout->addWidget(txtParamX);
    keyRightLayout->addWidget(new QLabel("Giá trị khóa công khai y = g^x mod p:"));
    keyRightLayout->addWidget(txtParamY);

    keysLayout->addWidget(grpKeyLeft, 45);
    keysLayout->addWidget(grpKeyRight, 55);
    tabWidget->addTab(tabKeys, "🔑 Cấu hình & Tạo Khóa");

    // ================= TAB 2: THỰC HIỆN KÝ SỐ =================
    QWidget *tabSign = new QWidget();
    QVBoxLayout *signLayout = new QVBoxLayout(tabSign);
    signLayout->setContentsMargins(10, 10, 10, 10);
    signLayout->setSpacing(10);

    QGroupBox *grpSignInput = new QGroupBox("1. Thiết lập nguồn dữ liệu cần ký");
    QVBoxLayout *signInputLayout = new QVBoxLayout(grpSignInput);
    signInputLayout->setSpacing(8);

    QHBoxLayout *signSourceLayout = new QHBoxLayout();
    signSourceLayout->addWidget(new QLabel("Kiểu dữ liệu đầu vào:"));
    cmbSignInputType = new QComboBox();
    cmbSignInputType->addItem("✍️ Văn bản trực tiếp");
    cmbSignInputType->addItem("📂 Tệp tin dữ liệu");
    cmbSignInputType->setMinimumHeight(32);
    signSourceLayout->addWidget(cmbSignInputType);
    signSourceLayout->addStretch();
    signInputLayout->addLayout(signSourceLayout);

    // Widget text đầu vào
    widgetSignText = new QWidget();
    QVBoxLayout *signTextLayout = new QVBoxLayout(widgetSignText);
    signTextLayout->setContentsMargins(0, 0, 0, 0);
    txtSignInput = new QTextEdit();
    txtSignInput->setPlaceholderText("Nhập nội dung văn bản cần ký số tại đây...");
    txtSignInput->setMinimumHeight(80);
    txtSignInput->setMaximumHeight(130);
    signTextLayout->addWidget(txtSignInput);
    signInputLayout->addWidget(widgetSignText);

    // Widget file đầu vào
    widgetSignFile = new QWidget();
    QHBoxLayout *signFileLayout = new QHBoxLayout(widgetSignFile);
    signFileLayout->setContentsMargins(0, 0, 0, 0);
    txtSignFilePath = new QLineEdit();
    txtSignFilePath->setReadOnly(true);
    txtSignFilePath->setPlaceholderText("Chưa chọn tệp tin...");
    txtSignFilePath->setMinimumHeight(32);
    btnBrowseSignFile = new QPushButton("🔍 Chọn Tệp...");
    btnBrowseSignFile->setMinimumHeight(32);
    signFileLayout->addWidget(txtSignFilePath);
    signFileLayout->addWidget(btnBrowseSignFile);
    widgetSignFile->setVisible(false);
    signInputLayout->addWidget(widgetSignFile);

    // Dòng hiển thị mã băm SHA-256
    QHBoxLayout *signHashLayout = new QHBoxLayout();
    signHashLayout->addWidget(new QLabel("Mã băm SHA-256 (Hex):"));
    txtSignHash = new QLineEdit();
    txtSignHash->setReadOnly(true);
    txtSignHash->setPlaceholderText("Tự động tính toán khi nhập dữ liệu...");
    txtSignHash->setStyleSheet("font-family: 'Consolas', monospace; color: #FFD200; font-weight: bold;");
    txtSignHash->setMinimumHeight(32);
    signHashLayout->addWidget(txtSignHash);
    signInputLayout->addLayout(signHashLayout);

    btnSignProcess = new QPushButton("✍️ Thực hiện Ký Số");
    btnSignProcess->setMinimumHeight(45);
    btnSignProcess->setCursor(Qt::PointingHandCursor);

    QGroupBox *grpSignResult = new QGroupBox("2. Kết quả chữ ký số sinh ra");
    QVBoxLayout *signResultLayout = new QVBoxLayout(grpSignResult);
    signResultLayout->setSpacing(8);

    QHBoxLayout *sigBase64Header = new QHBoxLayout();
    sigBase64Header->addWidget(new QLabel("Chữ ký số (Base64 / ASN.1 DER):"));
    btnSaveSignature = new QPushButton("💾 Lưu Chữ Ký");
    btnSaveSignature->setFixedSize(110, 26);
    sigBase64Header->addWidget(btnSaveSignature);
    
    txtSignOutput = new QTextEdit();
    txtSignOutput->setReadOnly(true);
    txtSignOutput->setPlaceholderText("Kết quả chữ ký số dạng Base64...");
    txtSignOutput->setMaximumHeight(70);

    QGridLayout *sigComponents = new QGridLayout();
    txtSignR = new QTextEdit();
    txtSignR->setReadOnly(true);
    txtSignR->setPlaceholderText("Tham số chữ ký r (Hex)");
    txtSignR->setMaximumHeight(65);

    txtSignS = new QTextEdit();
    txtSignS->setReadOnly(true);
    txtSignS->setPlaceholderText("Tham số chữ ký s (Hex)");
    txtSignS->setMaximumHeight(65);

    sigComponents->addWidget(new QLabel("Thành phần r (Hex):"), 0, 0);
    sigComponents->addWidget(txtSignR, 1, 0);
    sigComponents->addWidget(new QLabel("Thành phần s (Hex):"), 0, 1);
    sigComponents->addWidget(txtSignS, 1, 1);

    signResultLayout->addLayout(sigBase64Header);
    signResultLayout->addWidget(txtSignOutput);
    signResultLayout->addLayout(sigComponents);

    signLayout->addWidget(grpSignInput);
    signLayout->addWidget(btnSignProcess);
    signLayout->addWidget(grpSignResult);
    tabWidget->addTab(tabSign, "✍️ Thực hiện Ký Số");

    // ================= TAB 3: ĐỐI CHIẾU & XÁC MINH =================
    QWidget *tabVerify = new QWidget();
    QVBoxLayout *verifyLayout = new QVBoxLayout(tabVerify);
    verifyLayout->setContentsMargins(10, 10, 10, 10);
    verifyLayout->setSpacing(10);

    QGroupBox *grpVerifyInput = new QGroupBox("1. Nhập dữ liệu cần xác minh (M')");
    QVBoxLayout *verifyInputLayout = new QVBoxLayout(grpVerifyInput);
    verifyInputLayout->setSpacing(8);

    QHBoxLayout *verifySourceLayout = new QHBoxLayout();
    verifySourceLayout->addWidget(new QLabel("Kiểu dữ liệu đầu vào:"));
    cmbVerifyInputType = new QComboBox();
    cmbVerifyInputType->addItem("✍️ Văn bản trực tiếp");
    cmbVerifyInputType->addItem("📂 Tệp tin dữ liệu");
    cmbVerifyInputType->setMinimumHeight(32);
    verifySourceLayout->addWidget(cmbVerifyInputType);
    verifySourceLayout->addStretch();
    verifyInputLayout->addLayout(verifySourceLayout);

    // Widget text xác minh
    widgetVerifyText = new QWidget();
    QVBoxLayout *verifyTextLayout = new QVBoxLayout(widgetVerifyText);
    verifyTextLayout->setContentsMargins(0, 0, 0, 0);
    txtVerifyInput = new QTextEdit();
    txtVerifyInput->setPlaceholderText("Nhập nội dung văn bản cần đối soát...");
    txtVerifyInput->setMinimumHeight(60);
    txtVerifyInput->setMaximumHeight(90);
    verifyTextLayout->addWidget(txtVerifyInput);
    verifyInputLayout->addWidget(widgetVerifyText);

    // Widget file xác minh
    widgetVerifyFile = new QWidget();
    QHBoxLayout *verifyFileLayout = new QHBoxLayout(widgetVerifyFile);
    verifyFileLayout->setContentsMargins(0, 0, 0, 0);
    txtVerifyFilePath = new QLineEdit();
    txtVerifyFilePath->setReadOnly(true);
    txtVerifyFilePath->setPlaceholderText("Chưa chọn tệp tin...");
    txtVerifyFilePath->setMinimumHeight(32);
    btnBrowseVerifyFile = new QPushButton("🔍 Chọn Tệp...");
    btnBrowseVerifyFile->setMinimumHeight(32);
    verifyFileLayout->addWidget(txtVerifyFilePath);
    verifyFileLayout->addWidget(btnBrowseVerifyFile);
    widgetVerifyFile->setVisible(false);
    verifyInputLayout->addWidget(widgetVerifyFile);

    // Dòng hiển thị mã băm SHA-256 xác minh
    QHBoxLayout *verifyHashLayout = new QHBoxLayout();
    verifyHashLayout->addWidget(new QLabel("Mã băm SHA-256 (Hex):"));
    txtVerifyHash = new QLineEdit();
    txtVerifyHash->setReadOnly(true);
    txtVerifyHash->setPlaceholderText("Tự động tính toán khi nhập dữ liệu...");
    txtVerifyHash->setStyleSheet("font-family: 'Consolas', monospace; color: #FFD200; font-weight: bold;");
    txtVerifyHash->setMinimumHeight(32);
    verifyHashLayout->addWidget(txtVerifyHash);
    verifyInputLayout->addLayout(verifyHashLayout);

    QGroupBox *grpVerifySig = new QGroupBox("2. Nhập thông tin Chữ ký để đối soát (r', s')");
    QVBoxLayout *verifySigLayout = new QVBoxLayout(grpVerifySig);
    verifySigLayout->setSpacing(8);

    QHBoxLayout *sigVerifyHeader = new QHBoxLayout();
    sigVerifyHeader->addWidget(new QLabel("Chữ ký Base64 (hoặc tự động đồng bộ từ Tab Ký Số):"));
    btnLoadSignature = new QPushButton("📂 Tải Chữ Ký");
    btnLoadSignature->setFixedSize(110, 26);
    sigVerifyHeader->addWidget(btnLoadSignature);

    txtVerifySignature = new QTextEdit();
    txtVerifySignature->setPlaceholderText("Dán chữ ký dạng Base64 vào đây...");
    txtVerifySignature->setMaximumHeight(50);
    txtVerifySignature->setAcceptRichText(false);

    QGridLayout *verifyComponents = new QGridLayout();
    txtVerifyR = new QTextEdit();
    txtVerifyR->setPlaceholderText("Nhập r (Hex)...");
    txtVerifyR->setMaximumHeight(50);
    txtVerifyR->setAcceptRichText(false);

    txtVerifyS = new QTextEdit();
    txtVerifyS->setPlaceholderText("Nhập s (Hex)...");
    txtVerifyS->setMaximumHeight(50);
    txtVerifyS->setAcceptRichText(false);

    verifyComponents->addWidget(new QLabel("Thành phần r (Hex):"), 0, 0);
    verifyComponents->addWidget(txtVerifyR, 1, 0);
    verifyComponents->addWidget(new QLabel("Thành phần s (Hex):"), 0, 1);
    verifyComponents->addWidget(txtVerifyS, 1, 1);

    verifySigLayout->addLayout(sigVerifyHeader);
    verifySigLayout->addWidget(txtVerifySignature);
    verifySigLayout->addLayout(verifyComponents);

    btnVerifyProcess = new QPushButton("🛡️ Kiểm Tra & Xác Minh Chữ Ký");
    btnVerifyProcess->setMinimumHeight(45);
    btnVerifyProcess->setCursor(Qt::PointingHandCursor);

    lblVerifyResult = new QLabel("Trạng thái: Chờ tải dữ liệu kiểm tra...");
    lblVerifyResult->setAlignment(Qt::AlignCenter);
    lblVerifyResult->setWordWrap(true);

    verifyLayout->addWidget(grpVerifyInput);
    verifyLayout->addWidget(grpVerifySig);
    verifyLayout->addWidget(btnVerifyProcess);
    verifyLayout->addWidget(lblVerifyResult);
    tabWidget->addTab(tabVerify, "🛡️ Xác Minh Chữ Ký");

    // ================= KHU VỰC NHẬT KÝ (LOG) =================
    QGroupBox *grpLog = new QGroupBox("Nhật ký xử lý hệ thống (Console Log)");
    QVBoxLayout *logLayout = new QVBoxLayout(grpLog);
    logLayout->setContentsMargins(10, 10, 10, 10);
    txtSystemLog = new QTextBrowser();
    txtSystemLog->setMinimumHeight(120);
    txtSystemLog->setMaximumHeight(160);
    logLayout->addWidget(txtSystemLog);

    // Gắn vào Layout chính
    mainLayout->addWidget(tabWidget);
    mainLayout->addWidget(grpLog);
}

// In log ra màn hình console phong cách Terminal
void MainWindow::log(const QString &message, const QString &type) {
    QString timeStr = QDateTime::currentDateTime().toString("hh:mm:ss");

    QString color = "#D4D4D4";
    if (type == "ERROR") color = "#EF4444";      // Red
    else if (type == "SUCCESS") color = "#10B981"; // Green
    else if (type == "SYSTEM") color = "#00BCFF";  // Blue
    else if (type == "WARNING") color = "#F59E0B"; // Amber

    QString logLine = QString("<span style='color:#64748B;'>[%1]</span> "
                              "<b><span style='color:%2;'>[%3]</span></b> "
                              "<span style='color:#E2E8F0;'>%4</span>")
                          .arg(timeStr).arg(color).arg(type).arg(message);

    txtSystemLog->append(logLine);
}

// Áp dụng Style QSS (Sleek Space Dark Theme)
void MainWindow::applyStyle() {
    QString css = R"(
        /* Cấu hình chung cho ứng dụng */
        QWidget {
            font-family: 'Segoe UI', -apple-system, sans-serif;
            font-size: 13px;
            color: #E2E8F0;
        }

        QMainWindow {
            background-color: #0B0F19; /* Deep Space Dark */
        }

        /* QTabWidget */
        QTabWidget::pane {
            border: 1px solid #1E293B;
            background-color: #111827; /* Dark Slate Gray */
            border-radius: 8px;
            top: -1px;
        }

        QTabBar::tab {
            background-color: #1F2937;
            color: #9CA3AF;
            padding: 10px 20px;
            margin-right: 4px;
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            font-weight: bold;
            border: 1px solid #1E293B;
            border-bottom: none;
        }

        QTabBar::tab:selected {
            background-color: #111827;
            color: #3B82F6; /* Bright Electric Blue */
            border-bottom: 2px solid #3B82F6;
        }

        QTabBar::tab:hover:!selected {
            background-color: #374151;
            color: #F3F4F6;
        }

        /* QGroupBox */
        QGroupBox {
            background-color: #111827;
            border: 1px solid #1E293B;
            border-radius: 8px;
            margin-top: 15px;
            font-weight: bold;
            font-size: 13px;
        }

        QGroupBox::title {
            subcontrol-origin: margin;
            subcontrol-position: top left;
            padding: 4px 10px;
            background-color: #1E3A8A; /* Dark Indigo Blue */
            color: #FFFFFF;
            border-radius: 4px;
            left: 15px;
        }

        /* Input / Output (QTextEdit & QLineEdit) */
        QTextEdit, QLineEdit {
            background-color: #030712; /* Extreme dark */
            border: 1px solid #1E293B;
            border-radius: 6px;
            padding: 8px;
            color: #E2E8F0;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 13px;
        }

        QTextEdit:focus, QLineEdit:focus {
            border: 2px solid #3B82F6; /* Focus Electric Blue */
        }

        /* QComboBox */
        QComboBox {
            background-color: #1F2937;
            border: 1px solid #1E293B;
            border-radius: 6px;
            padding: 4px 10px;
            color: #F3F4F6;
            font-weight: bold;
            min-width: 150px;
        }

        QComboBox::drop-down {
            subcontrol-origin: padding;
            subcontrol-position: top right;
            width: 25px;
            border-left: 1px solid #1E293B;
        }

        QComboBox QAbstractItemView {
            background-color: #111827;
            border: 1px solid #1E293B;
            selection-background-color: #3B82F6;
            selection-color: white;
            color: #F3F4F6;
        }

        /* Nút Bấm Chính (Gradient Button) */
        QPushButton {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #2563EB, stop:1 #3B82F6);
            color: #FFFFFF;
            border: none;
            border-radius: 6px;
            padding: 6px 12px;
            font-weight: bold;
        }

        QPushButton:hover {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                        stop:0 #1D4ED8, stop:1 #2563EB);
        }

        QPushButton:pressed {
            background: #1E40AF;
        }

        /* Nút phụ / Nút Lưu/Tải */
        QPushButton[text="📂 Tải"], QPushButton[text="💾 Lưu"], QPushButton[text="🔍 Chọn Tệp..."], 
        QPushButton[text="📂 Tải Khóa"], QPushButton[text="💾 Lưu Khóa"], QPushButton[text="📂 Tải Chữ Ký"], 
        QPushButton[text="💾 Lưu Chữ Ký"] {
            background-color: #1F2937;
            border: 1px solid #374151;
            color: #F3F4F6;
            border-radius: 4px;
            font-size: 11px;
            font-weight: normal;
        }

        QPushButton[text="📂 Tải"]:hover, QPushButton[text="💾 Lưu"]:hover, QPushButton[text="🔍 Chọn Tệp..."]:hover,
        QPushButton[text="📂 Tải Chữ Ký"]:hover, QPushButton[text="💾 Lưu Chữ Ký"]:hover {
            background-color: #374151;
            border: 1px solid #4B5563;
        }

        /* Terminal Log Window */
        QTextBrowser {
            background-color: #030712;
            color: #C8D6E5;
            border: 1px solid #1E293B;
            border-radius: 6px;
            font-family: 'Consolas', 'Courier New', monospace;
            font-size: 12px;
            line-height: 1.4;
        }

        /* ScrollBar */
        QScrollBar:vertical {
            border: none;
            background: #030712;
            width: 8px;
            margin: 0px 0px 0px 0px;
        }

        QScrollBar::handle:vertical {
            background: #374151;
            min-height: 20px;
            border-radius: 4px;
        }

        QScrollBar::handle:vertical:hover {
            background: #4B5563;
        }

        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
            height: 0px;
        }
    )";
    this->setStyleSheet(css);

    // Style cho phần hiển thị kết quả kiểm tra
    lblVerifyResult->setStyleSheet(
        "font-size: 15px; font-weight: bold; color: #94A3B8; "
        "padding: 15px; border: 2px dashed #334155; "
        "background-color: #0F172A; border-radius: 8px;"
    );
}

// Kết nối các tín hiệu (Signals & Slots)
void MainWindow::connectSignals() {
    
    // Tự động đặt lại trạng thái kết quả xác minh khi có bất kỳ thông tin đầu vào nào thay đổi (bao gồm cả Khóa công khai)
    auto resetVerifyResult = [=]() {
        lblVerifyResult->setText("Trạng thái: Chờ tải dữ liệu kiểm tra...");
        lblVerifyResult->setStyleSheet(
            "font-size: 15px; font-weight: bold; color: #94A3B8; "
            "padding: 15px; border: 2px dashed #334155; "
            "background-color: #0F172A; border-radius: 8px;"
        );
    };

    connect(txtPublicKey, &QTextEdit::textChanged, this, resetVerifyResult);
    connect(txtVerifyInput, &QTextEdit::textChanged, this, resetVerifyResult);
    connect(txtVerifyFilePath, &QLineEdit::textChanged, this, resetVerifyResult);
    connect(txtVerifySignature, &QTextEdit::textChanged, this, resetVerifyResult);
    connect(txtVerifyR, &QTextEdit::textChanged, this, resetVerifyResult);
    connect(txtVerifyS, &QTextEdit::textChanged, this, resetVerifyResult);
    connect(cmbVerifyInputType, &QComboBox::currentIndexChanged, this, resetVerifyResult);

    // --- KHỞI TẠO ĐỒNG BỘ MÃ BĂM SHA-256 ---
    connect(txtSignInput, &QTextEdit::textChanged, this, &MainWindow::updateSignHash);
    connect(txtVerifyInput, &QTextEdit::textChanged, this, &MainWindow::updateVerifyHash);

    // Chuyển đổi nguồn vào của Ký số (Text vs File)
    connect(cmbSignInputType, &QComboBox::currentIndexChanged, this, [=]() {
        int index = cmbSignInputType->currentIndex();
        widgetSignText->setVisible(index == 0);
        widgetSignFile->setVisible(index == 1);
        updateSignHash();
    });

    // Chuyển đổi nguồn vào của Xác minh (Text vs File)
    connect(cmbVerifyInputType, &QComboBox::currentIndexChanged, this, [=]() {
        int index = cmbVerifyInputType->currentIndex();
        widgetVerifyText->setVisible(index == 0);
        widgetVerifyFile->setVisible(index == 1);
        updateVerifyHash();
    });

    // --- SỰ KIỆN CHỌN TỆP ---
    connect(btnBrowseSignFile, &QPushButton::clicked, this, [=]() {
        QString filePath = QFileDialog::getOpenFileName(this, "Chọn tệp cần ký", "", "Tất cả các tệp (*)");
        if (!filePath.isEmpty()) {
            txtSignFilePath->setText(filePath);
            log("Đã chọn tệp tin cần ký: " + filePath, "INFO");
            updateSignHash();
        }
    });

    connect(btnBrowseVerifyFile, &QPushButton::clicked, this, [=]() {
        QString filePath = QFileDialog::getOpenFileName(this, "Chọn tệp tin để xác minh", "", "Tất cả các tệp (*)");
        if (!filePath.isEmpty()) {
            txtVerifyFilePath->setText(filePath);
            log("Đã chọn tệp tin để đối chiếu: " + filePath, "INFO");
            updateVerifyHash();
        }
    });

    // --- SỰ KIỆN 1: SINH CẶP KHÓA MỚI ---
    connect(btnGenerateKeys, &QPushButton::clicked, this, [=]() {
        log("Đang cấu hình tham số DSA mới...", "SYSTEM");
        int bits = cmbKeySize->currentData().toInt();
        log(QString("Độ dài khóa yêu cầu: %1-bit Modulus.").arg(bits), "INFO");
        
        QString privPem, pubPem, p_hex, q_hex, g_hex, x_hex, y_hex, errorMsg;
        
        bool ok = DSACrypto::generateKeyPair(bits, privPem, pubPem, p_hex, q_hex, g_hex, x_hex, y_hex, errorMsg);
        
        if (ok) {
            txtPrivateKey->setPlainText(privPem);
            txtPublicKey->setPlainText(pubPem);
            
            // Điền các tham số toán học hiển thị
            txtParamP->setPlainText(p_hex);
            txtParamQ->setPlainText(q_hex);
            txtParamG->setPlainText(g_hex);
            txtParamX->setPlainText(x_hex);
            txtParamY->setPlainText(y_hex);
            
            log("Sinh thành công bộ tham số p, q, g.", "SUCCESS");
            log("Sinh thành công cặp khóa riêng (x) và khóa công khai (y).", "SUCCESS");
            log("-> Kích thước p: " + QString::number(p_hex.length() * 4) + " bits", "INFO");
            log("-> Kích thước q: " + QString::number(q_hex.length() * 4) + " bits", "INFO");
        } else {
            log("Lỗi sinh khóa: " + errorMsg, "ERROR");
            QMessageBox::critical(this, "Lỗi", "Không thể sinh khóa: " + errorMsg);
        }
    });

    // --- SỰ KIỆN 2: THỰC HIỆN KÝ SỐ ---
    connect(btnSignProcess, &QPushButton::clicked, this, [=]() {
        log("Bắt đầu xử lý ký số dữ liệu...", "SYSTEM");
        
        QByteArray data;
        int inputType = cmbSignInputType->currentIndex();
        
        if (inputType == 0) { // Text
            data = txtSignInput->toPlainText().toUtf8();
            if (data.isEmpty()) {
                log("Lỗi: Dữ liệu văn bản đầu vào trống!", "ERROR");
                QMessageBox::warning(this, "Cảnh báo", "Vui lòng nhập văn bản cần ký.");
                return;
            }
        } else { // File
            QString filePath = txtSignFilePath->text();
            if (filePath.isEmpty()) {
                log("Lỗi: Chưa chọn tệp tin cần ký!", "ERROR");
                QMessageBox::warning(this, "Cảnh báo", "Vui lòng chọn tệp tin dữ liệu.");
                return;
            }
            QFile file(filePath);
            if (file.open(QIODevice::ReadOnly)) {
                data = file.readAll();
                file.close();
            } else {
                log("Lỗi: Không thể mở tệp: " + file.errorString(), "ERROR");
                QMessageBox::critical(this, "Lỗi", "Không thể đọc tệp: " + file.errorString());
                return;
            }
        }

        QString privKey = txtPrivateKey->toPlainText().trimmed();
        if (privKey.isEmpty()) {
            log("Lỗi: Thiếu Khóa bí mật (Private Key)!", "ERROR");
            QMessageBox::warning(this, "Cảnh báo", "Vui lòng tạo hoặc tải Khóa bí mật trước khi ký.");
            return;
        }

        log("Bước 1: Tính toán băm SHA-256 dữ liệu...", "INFO");
        QString hashHex = DSACrypto::sha256Hex(data);
        log("-> H(M) = " + hashHex, "INFO");

        log("Bước 2: Sử dụng thuật toán DSA để tạo chữ ký (r, s)...", "INFO");
        QString sigBase64, r_hex, s_hex, errorMsg;
        
        if (DSACrypto::signData(data, privKey, sigBase64, r_hex, s_hex, errorMsg)) {
            txtSignOutput->setPlainText(sigBase64);
            txtSignR->setPlainText(r_hex);
            txtSignS->setPlainText(s_hex);
            
            log("-> Thành phần chữ ký r (Hex) = " + r_hex, "INFO");
            log("-> Thành phần chữ ký s (Hex) = " + s_hex, "INFO");
            log("Đóng gói thành công chữ ký số dạng Base64.", "SUCCESS");

            // Tự động sao chép sang Tab Xác minh để tối ưu hóa trải nghiệm
            if (inputType == 0) {
                cmbVerifyInputType->setCurrentIndex(0);
                txtVerifyInput->setPlainText(txtSignInput->toPlainText());
            } else {
                cmbVerifyInputType->setCurrentIndex(1);
                txtVerifyFilePath->setText(txtSignFilePath->text());
            }
            txtVerifySignature->setPlainText(sigBase64);
            txtVerifyR->setPlainText(r_hex);
            txtVerifyS->setPlainText(s_hex);
            updateVerifyHash();
            
            log("Hệ thống tự động liên kết dữ liệu và chữ ký số sang Tab Xác Minh.", "INFO");
        } else {
            log("Ký số thất bại: " + errorMsg, "ERROR");
            QMessageBox::critical(this, "Lỗi", "Ký số thất bại: " + errorMsg);
        }
    });

    // --- SỰ KIỆN 3: XÁC MINH CHỮ KÝ ---
    connect(btnVerifyProcess, &QPushButton::clicked, this, [=]() {
        log("Bắt đầu quy trình đối soát xác minh...", "SYSTEM");
        
        QByteArray data;
        int inputType = cmbVerifyInputType->currentIndex();
        
        if (inputType == 0) { // Text
            data = txtVerifyInput->toPlainText().toUtf8();
        } else { // File
            QString filePath = txtVerifyFilePath->text();
            if (filePath.isEmpty()) {
                log("Lỗi: Chưa chọn tệp tin cần xác minh!", "ERROR");
                QMessageBox::warning(this, "Cảnh báo", "Vui lòng chọn tệp tin cần xác minh.");
                return;
            }
            QFile file(filePath);
            if (file.open(QIODevice::ReadOnly)) {
                data = file.readAll();
                file.close();
            } else {
                log("Lỗi: Không thể mở tệp: " + file.errorString(), "ERROR");
                return;
            }
        }

        QString pubKey = txtPublicKey->toPlainText().trimmed();
        if (pubKey.isEmpty()) {
            log("Lỗi: Chưa nhập Khóa công khai (Public Key)!", "ERROR");
            QMessageBox::warning(this, "Cảnh báo", "Vui lòng nhập hoặc tải Khóa công khai của bên gửi.");
            return;
        }

        QString sigBase64 = txtVerifySignature->toPlainText().trimmed();
        if (sigBase64.isEmpty()) {
            log("Lỗi: Thiếu thông tin Chữ ký số để xác minh!", "ERROR");
            QMessageBox::warning(this, "Cảnh báo", "Vui lòng nhập hoặc dán chữ ký số.");
            return;
        }

        log("Bước 1: Tính toán băm SHA-256 của tài liệu nhận được...", "INFO");
        QString hashHex = DSACrypto::sha256Hex(data);
        log("-> H(M') = " + hashHex, "INFO");

        log("Bước 2: Gọi thư viện xác thực chữ ký DSA...", "INFO");
        QString errorMsg;
        bool valid = DSACrypto::verifyData(data, pubKey, sigBase64, errorMsg);
        
        if (valid) {
            lblVerifyResult->setText("✅ KẾT QUẢ: CHỮ KÝ HỢP LỆ (DỮ LIỆU TOÀN VẸN)");
            lblVerifyResult->setStyleSheet(
                "font-size: 15px; font-weight: bold; color: #10B981; "
                "padding: 15px; border: 2px solid #10B981; "
                "background-color: #062E1B; border-radius: 8px;"
            );
            log("XÁC MINH THÀNH CÔNG: Chữ ký số hoàn toàn khớp. Tài liệu không bị chỉnh sửa.", "SUCCESS");
        } else {
            lblVerifyResult->setText("❌ KẾT QUẢ: XÁC MINH THẤT BẠI\n(Chi tiết: " + errorMsg + ")");
            lblVerifyResult->setStyleSheet(
                "font-size: 15px; font-weight: bold; color: #EF4444; "
                "padding: 15px; border: 2px solid #EF4444; "
                "background-color: #3B0F0F; border-radius: 8px;"
            );
            log("XÁC MINH THẤT BẠI: " + errorMsg, "ERROR");
        }
    });

    // --- LIÊN KẾT BI-DIRECTIONAL CHO PHẦN XÁC MINH CHỮ KÝ ---
    // 1. Khi thay đổi ô Base64
    connect(txtVerifySignature, &QTextEdit::textChanged, this, [=]() {
        if (txtVerifySignature->hasFocus()) {
            QString base64Sig = txtVerifySignature->toPlainText().trimmed();
            if (base64Sig.isEmpty()) {
                txtVerifyR->blockSignals(true);
                txtVerifyS->blockSignals(true);
                txtVerifyR->clear();
                txtVerifyS->clear();
                txtVerifyR->blockSignals(false);
                txtVerifyS->blockSignals(false);
                return;
            }
            QString r_hex, s_hex, errorMsg;
            if (DSACrypto::decodeSignature(base64Sig, r_hex, s_hex, errorMsg)) {
                txtVerifyR->blockSignals(true);
                txtVerifyS->blockSignals(true);
                txtVerifyR->setPlainText(r_hex);
                txtVerifyS->setPlainText(s_hex);
                txtVerifyR->blockSignals(false);
                txtVerifyS->blockSignals(false);
                log("Đã tự động trích xuất các thành phần r và s từ chữ ký Base64.", "INFO");
            }
        }
    });

    // 2. Khi thay đổi ô r hoặc s
    auto updateBase64FromRS = [=]() {
        if (txtVerifyR->hasFocus() || txtVerifyS->hasFocus()) {
            QString r_hex = txtVerifyR->toPlainText().trimmed();
            QString s_hex = txtVerifyS->toPlainText().trimmed();
            if (r_hex.isEmpty() || s_hex.isEmpty()) {
                txtVerifySignature->blockSignals(true);
                txtVerifySignature->clear();
                txtVerifySignature->blockSignals(false);
                return;
            }
            QString signatureBase64, errorMsg;
            if (DSACrypto::encodeSignature(r_hex, s_hex, signatureBase64, errorMsg)) {
                txtVerifySignature->blockSignals(true);
                txtVerifySignature->setPlainText(signatureBase64);
                txtVerifySignature->blockSignals(false);
            }
        }
    };
    connect(txtVerifyR, &QTextEdit::textChanged, this, updateBase64FromRS);
    connect(txtVerifyS, &QTextEdit::textChanged, this, updateBase64FromRS);

    // --- SỰ KIỆN LƯU & TẢI FILE PHỤ ---
    // Lưu Khóa Bí Mật
    connect(btnSavePrivateKey, &QPushButton::clicked, this, [=]() {
        QString content = txtPrivateKey->toPlainText();
        if (content.isEmpty()) return;
        QString fileName = QFileDialog::getSaveFileName(this, "Lưu Khóa Bí Mật", "private_key.pem", "PEM Files (*.pem);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                QTextStream out(&file);
                out << content;
                file.close();
                log("Đã lưu Khóa Bí Mật vào tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi lưu file: " + file.errorString(), "ERROR");
            }
        }
    });

    // Tải Khóa Bí Mật
    connect(btnLoadPrivateKey, &QPushButton::clicked, this, [=]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Tải Khóa Bí Mật", "", "PEM Files (*.pem);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&file);
                txtPrivateKey->setPlainText(in.readAll());
                file.close();
                log("Đã tải Khóa Bí Mật từ tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi đọc file: " + file.errorString(), "ERROR");
            }
        }
    });

    // Lưu Khóa Công Khai
    connect(btnSavePublicKey, &QPushButton::clicked, this, [=]() {
        QString content = txtPublicKey->toPlainText();
        if (content.isEmpty()) return;
        QString fileName = QFileDialog::getSaveFileName(this, "Lưu Khóa Công Khai", "public_key.pem", "PEM Files (*.pem);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                QTextStream out(&file);
                out << content;
                file.close();
                log("Đã lưu Khóa Công Khai vào tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi lưu file: " + file.errorString(), "ERROR");
            }
        }
    });

    // Tải Khóa Công Khai
    connect(btnLoadPublicKey, &QPushButton::clicked, this, [=]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Tải Khóa Công Khai", "", "PEM Files (*.pem);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&file);
                txtPublicKey->setPlainText(in.readAll());
                file.close();
                log("Đã tải Khóa Công Khai từ tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi đọc file: " + file.errorString(), "ERROR");
            }
        }
    });

    // Lưu Chữ Ký
    connect(btnSaveSignature, &QPushButton::clicked, this, [=]() {
        QString content = txtSignOutput->toPlainText();
        if (content.isEmpty()) return;
        QString fileName = QFileDialog::getSaveFileName(this, "Lưu Chữ Ký Số", "signature.sig", "Signature Files (*.sig *.txt);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                QTextStream out(&file);
                out << content;
                file.close();
                log("Đã lưu Chữ Ký Số vào tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi lưu chữ ký: " + file.errorString(), "ERROR");
            }
        }
    });

    // Tải Chữ Ký
    connect(btnLoadSignature, &QPushButton::clicked, this, [=]() {
        QString fileName = QFileDialog::getOpenFileName(this, "Tải Chữ Ký Số", "", "Signature Files (*.sig *.txt);;All Files (*)");
        if (!fileName.isEmpty()) {
            QFile file(fileName);
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&file);
                txtVerifySignature->setPlainText(in.readAll().trimmed());
                file.close();
                log("Đã tải Chữ Ký Số từ tệp: " + fileName, "SUCCESS");
            } else {
                log("Lỗi đọc chữ ký: " + file.errorString(), "ERROR");
            }
        }
    });
}

// Cập nhật mã băm SHA-256 Tab Ký Số
void MainWindow::updateSignHash() {
    int index = cmbSignInputType->currentIndex();
    if (index == 0) { // Text
        QByteArray data = txtSignInput->toPlainText().toUtf8();
        if (data.isEmpty()) {
            txtSignHash->clear();
        } else {
            txtSignHash->setText(DSACrypto::sha256Hex(data));
        }
    } else { // File
        QString filePath = txtSignFilePath->text();
        if (filePath.isEmpty()) {
            txtSignHash->clear();
            return;
        }
        QFile file(filePath);
        if (file.open(QIODevice::ReadOnly)) {
            QByteArray data = file.readAll();
            file.close();
            txtSignHash->setText(DSACrypto::sha256Hex(data));
        } else {
            txtSignHash->setText("Lỗi đọc tệp tin!");
        }
    }
}

// Cập nhật mã băm SHA-256 Tab Xác Minh
void MainWindow::updateVerifyHash() {
    int index = cmbVerifyInputType->currentIndex();
    if (index == 0) { // Text
        QByteArray data = txtVerifyInput->toPlainText().toUtf8();
        if (data.isEmpty()) {
            txtVerifyHash->clear();
        } else {
            txtVerifyHash->setText(DSACrypto::sha256Hex(data));
        }
    } else { // File
        QString filePath = txtVerifyFilePath->text();
        if (filePath.isEmpty()) {
            txtVerifyHash->clear();
            return;
        }
        QFile file(filePath);
        if (file.open(QIODevice::ReadOnly)) {
            QByteArray data = file.readAll();
            file.close();
            txtVerifyHash->setText(DSACrypto::sha256Hex(data));
        } else {
            txtVerifyHash->setText("Lỗi đọc tệp tin!");
        }
    }
}