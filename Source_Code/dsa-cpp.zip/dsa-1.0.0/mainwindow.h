#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QTextEdit>
#include <QTextBrowser>
#include <QLabel>
#include <QTabWidget>
#include <QGroupBox>
#include <QComboBox>
#include <QLineEdit>
#include <QRadioButton>
#include <QButtonGroup>

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    // Các hàm khởi tạo UI và xử lý sự kiện
    void setupUI();
    void applyStyle();
    void connectSignals();
    
    // Hàm tiện ích
    void log(const QString &message, const QString &type = "INFO");
    void updateSignHash();
    void updateVerifyHash();

    // --- CÁC THÀNH PHẦN GIAO DIỆN ---
    QTabWidget *tabWidget;
    QTextBrowser *txtSystemLog; // Cửa sổ log dưới cùng

    // Tab 1: Tạo Khóa
    QComboBox *cmbKeySize;
    QPushButton *btnGenerateKeys;
    QTextEdit *txtPrivateKey;
    QTextEdit *txtPublicKey;
    QPushButton *btnSavePrivateKey;
    QPushButton *btnLoadPrivateKey;
    QPushButton *btnSavePublicKey;
    QPushButton *btnLoadPublicKey;
    
    // Tham số toán học DSA
    QTextEdit *txtParamP;
    QTextEdit *txtParamQ;
    QTextEdit *txtParamG;
    QTextEdit *txtParamX;
    QTextEdit *txtParamY;

    // Tab 2: Ký Số
    QComboBox *cmbSignInputType; // 0: Nhập văn bản, 1: Chọn Tệp tin
    QWidget *widgetSignText;
    QTextEdit *txtSignInput;
    QWidget *widgetSignFile;
    QLineEdit *txtSignFilePath;
    QPushButton *btnBrowseSignFile;
    QLineEdit *txtSignHash;
    QPushButton *btnSignProcess;
    QTextEdit *txtSignOutput; // Base64
    QTextEdit *txtSignR;      // Tham số r (Hex)
    QTextEdit *txtSignS;      // Tham số s (Hex)
    QPushButton *btnSaveSignature;

    // Tab 3: Xác Minh
    QComboBox *cmbVerifyInputType; // 0: Nhập văn bản, 1: Chọn Tệp tin
    QWidget *widgetVerifyText;
    QTextEdit *txtVerifyInput;
    QWidget *widgetVerifyFile;
    QLineEdit *txtVerifyFilePath;
    QPushButton *btnBrowseVerifyFile;
    QLineEdit *txtVerifyHash;
    QTextEdit *txtVerifySignature; // Base64
    QTextEdit *txtVerifyR;         // Tham số r' (Hex)
    QTextEdit *txtVerifyS;         // Tham số s' (Hex)
    QPushButton *btnLoadSignature;
    QPushButton *btnVerifyProcess;
    QLabel *lblVerifyResult;
};

#endif // MAINWINDOW_H